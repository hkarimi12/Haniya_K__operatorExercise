// All of my variables
var first = 100
var second = 10
var third = 15
var fourth = 30
// operations
let add = first + second
let subtract = first - third
let devision = fourth / third
let multiplication = fourth * second
//results
print (add)
print (subtract)
print (devision)
print (multiplication)
